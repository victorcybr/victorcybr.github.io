 ________________________
| R. Mika by DeathScythe |
 ������������������������
           04/August/2019

 - deathscythemugen.neocities.org -
 - victor_crepa@hotmail.com -

     ----------

Customized version of Rainbow Mika from Street Fighter series, for MUGEN 1.0.
Based primarily on her SFA3 appearance.
Customizable options, including alternate commands, alternate hitsparks and choosing between
Custom Combo or MAX Mode. Open "custom.txt" for info.

     ----------

COMMENTS:

Why R. Mika? I like her, and there was no Mika in this style yet, so I decided to show her some
love >:)
This creation is opensource, you can take whatever you want from it, just give me credit
and give credit to people who I took resources from, see "SPECIAL THANKS" near the end of this
document to know more.

     ----------

MOVELIST:

U - Up           x - Light Punch       a - Light Kick
D - Down         y - Medium Punch      b - Medium Kick
F - Forward      z - Heavy Punch       c - Heavy Kick
B - Back         p - Any Punch         k - Any Kick
s - Start        2p - Two Punches      2k - Two Kicks

(Air) - Move must be performed in the air
(EX)  - Move has an EX version, performed by pressing 2 punch/kick buttons
(MAX) - Use 2 punch/kick buttons when performing a Super Move to power it up


NORMAL:

German Suplex:			B or F + 2p
Brain Buster:			B or F + 2k
Headbutt:			DB or DF + 2p (mash buttons)
Hip Buster:			B or F + 2p (Air)
NeckBreaker:			B or F + 2k (Air)
Flying Body Press:		D + z (while in diagonal jump)
Knee Drop:			D + a (while in diagonal jump)
Rainbow Sobat:			F + b


SPECIAL:

Flying Peach (EX):		D, DB, B, p
Shooting Peach (EX):		D, DB, B, k
Paradise Hold (EX):		360, p
Daydream Headlock:		360, k (mash buttons)
Wingless Airplane(EX):		F, DF, D, DB, B, k (air)


SUPER:

Heavenly Dynamite (MAX):	720, p (mash buttons) 			[default cmd]
Heavenly Dynamite (MAX):	D, DB, B, D, DB, B, p (mash buttons)	[easier  cmd]
Rainbow Hip Rush (MAX):		D, DF, F, D, DF, F, p
Sardine's Beach Special:	D, DF, F, D, DF, F, k
(after Sardine's Beach Special):
   Hashiru:				B or F
      Tobikoshi:			k (during Hashiru)
      Dageki: J. Ocean Drop Kick:	x (during Hashiru)
      Dageki: Mika Sliding:		y (during Hashiru)
      Dageki: Mika Lariat:		z (during Hashiru)
         Moonsault Press:		do nothing (after Dageki)
         Missile Kick:			k (after Dageki)

LV3 SUPER:

Rainbow Assault:		F, DF, D, DB, B, F, DF, D, DB, B, 2k	[default cmd]
Rainbow Assault:		D, DB, B, D, DB, B, 2k 			[easier  cmd]
Rainbow Cyclone:		D, DB, B, DB, D, DF, F, 2p


SYSTEM:

Forward Dash:			F, F
Run:				F, F (hold F)
Backward Dash:			B, B
Low Jump:			tap U
High Jump:			tap D, U
Long Low Jump:			tap D, tap U
Dodge:				a + x
Dodge Attack:			p or k during dodge
Forward Roll:			F + a + x
Backward Roll:			B + a + x
Parry:				tap F
Parry Low:			tap D
Air Parry:			tap F (Air)
Power Charge:			hold b + y
Zero Counter:			B, DB, D, p or k (during guard)
Custom Combo:			c + z (also in air)
Fall Recovery:			2p or a + x

     ----------

MOVE DETAILS:

EX Shooting Peach can hit lying down opponents
EX Flying Peach, EX Paradise Hold and Rainbow Hip Rush have a short invulnerability window at
the start
EX Wingless Airplane can grab falling opponents
Each move from Sardine's Beach Special have a different guardflag:
   J. Ocean Drop Kick can't be guarded in air
   Mika Sliding can't be guarded standing
   Mika Lariat can't be guarded crouching
To make sure you will use Missile Kick instead of Moonsault Press, hold k before Mika jumps off
the Ring


COMBO SYSTEM:

Some Normal attacks can be canceled into Special and Super moves
Some Special moves can be canceled into Super moves
Some Lv1 Super moves can be canceled into MAX Super moves
Cancelling a Special, Super move or Custom Combo into a Super move resets the juggle points
but also reduces its damage

CUSTOM COMBO:

Removes cancellable attack restrictions and gives you a lot of freedom to combo them
Juggle limite is lifted
You can only use EX Special or Super moves from the point the character starts flashing
faster and brighter, and doing so ends Custom Combo
Gives you a short invulnerability window at the start

MAX MODE:

Attack and Defense are increased while in MAX Mode
EX moves can be performed at no power cost, though take away from time sustained in MAX mode
All Lv1 supers can be performed at no power cost, though immediately uses up all time in MAX mode
All Lv2 and higher supers will cost 1 power bar, along with using up all time in MAX mode
Even without a power bar, as long as you have time left in MAX mode, you can perform Lv1 supers/EX moves
You can not Power Charge/gain power while in MAX mode
You can not perform a Zero Counter/Counter Movement while in MAX Mode

     ----------

VERSION HISTORY:

04/August/2019
Adjusted envshake for Heavenly Dynamite
Added envshake to Headbutt
Added envshake to Flying Peach and Shooting Peach
Added jump sound and effect for Heavenly Dynamite and Daydream Headlock
Added another Hyper Portrait by RagingRowen
Added butt slap intro (thanks to DelusionTrim & ReduxMercenaryT)
Fixed sprpriority on throws
Fixed camera issue in one of the winposes
Can now taunt after a KO

24/July/2019
Added Explodsive Buffering System by Just No Point & Jmorphman
Added Intro vs Zangief
Refined states and removed unused codes
Fixed moves going through opponent
Fixed pushbacks and corner push
Fixed damage dampening on some moves
Fixed cancels
Fixed many wrong priorities and hitflags
Added turns intro
Fixed throw changing sides
Some tweaks in the AI
Changed AI behavior in Custom Combo
Fixed AI using Custom Combo even if you select to use Max Mode
Rainbow Cyclone is now blockable
Heavenly Dynamite and Rainbow Assault can't connect when opponent is in hit state anymore
Due to this, she can no longer cancel a LV1 into Heavenly Dynamite as it would be useless
EX Moves uses 1/3 of the bar in MAX Mode, like updated DW chars
Included SFV Japanese voice by Gui007
Included alternate command for Rainbow Assault (only in Default command)
Fixed hitpauses
Changed sff to Beta (easier for making palettes)
Changed Hyper Portrait
Added variable list to Constants
Added Palettes
Added Palette Guide
Changed alternate commands to Custom.txt instead of making a new CMD file
Fixed Zangief's size
Fixed bugs when canceling grab specials
Pradise Hold entirely remade with better coding
EX Shooting Peach recovery removed when the move makes contact
Changed many animations and timing, mainly for normal attacks
Fixed missaligned hitsparks and hitboxes
MAX Rainbow Hip Rush do more hits like SFA3 lv3 version instead of lv2
Added EX Paradise Hold
Fixed Heavenly Dynamite not changing to final hit when opponent is about to die
Changed EX Shooting Peach velocity when canceling a normal into it
Changed Flying Peach & Shooting Peach (normal and EX) damage
EX Shooting Peach startup is now slightly faster

01/October/2018
Corrected statetype on some moves
Slightly increased the time to wait before changing from 'dash' to 'run' animation
Remade CLSN for hit animations
Deleted unused effects sprites and animations
Added more palettes

20/August/2018
Replacing sounds / changing effects (again)
Fixed cancels (again) and combo ability
Changed command for Rainbow Cyclone
Fixed some sprites with wrong color
Color Separated Midnight Bliss sprites
Changed all CLSN to look more like in SFA3
Re-aligned some sprites
Fixed Ring cut-off
Tweaked some moves
EX Wingless Airplane now can connect with opponent in falling state (good for combos :D)
Added AfterImage on EX Moves (can be disabled in config.txt)
Changed AfterImage on Custom Combo to look more like SFA3 V-ISM (can be changed in config.txt)
Changed default palette
Changed portrait

05/August/2018
Small fixes, mostly adding or replacing sounds / effects
LV1 Sardine's Beach now also make the opponent stay on the ground, like in MAX version
Removed "MAX" text on super finish (they will display the move name without the "MAX" now)
Fixed wrong damage on Sardine's Beach
Fixed cancels
Changed Rainbow Assault to look more like the LV3 Super from Warusaki's Mika
Added new victory portrait (9000,2) sprite
Added new Lv3 Super (Rainbow Cyclone), and a new Winpose for when you win using it
Other things that I forgot. lol

29/July/2018
First Beta Released

     ----------

WHAT IS MISSING:

Bug fixes, if any
Nadeshiko

     ----------

SECIAL THANKS:

Everyone from MugenGuild, always helping and treating me super nice
PotS, do I need to say something?
Jmorphman and DivineWolf, for reference I used to make my template
Jmorphman (again) and Just No Point for the Explodsive Buffering System
Ryon, for making the tutorial that inspired me to start creating chars
Memo, for the initial template
Warusaki3, for reference on some moves and custom sprites from his char
Tamago, for reference on some moves from his char
QuickFist, for color separation
altoiddealer, for coding help
Manson Rees, for coding help and feedback
DelusionTrim, for custom butt slap sprites
Sabockee, for custom midnight bliss sprites
IceJkai, for the small portrait
Gui007, for the video preview and the SFV japanese voice pack
Senorfro, PeXXeR, SolidZone26, Trololo, for testing and suggestions
RagingRowen, NDSilva, Quickfist and Gui007, for palettes
Everyone at MFG for feedback and suggestions
VirtuallTek, for creating Fighter Factory
Elecbyte, for creating MUGEN
Capcom, for creating Street Fighter and R. Mika
You, for downloading my char :D

     ----------

DISCLAIMER:

Street Fighter and Capcom vs SNK are property of Capcom
This MUGEN character is a non-profit fan work, it cannot be used for any commercial purposes