 _______________________
| Ingrid by DeathScythe |
 ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
		14/January/2024
	    crepa.neocities.org

Custom version of Capcom's Ingrid, for MUGEN 1.0+.
Based on her Capcom Fighting Jam and Street Fighter Alpha 3 MAX appearance.
Customizable options, including alternate hitsparks and choosing between Custom Combo or MAX Mode. Check "config.txt" for info.
Special Intro vs DivineWolf's Kula Diamond.
Special Intro vs KarmaCharmeleon's Blanka.

==================================================

Index

+ Move List
+ System
+ Move Details
+ Combo System
+ Custom Combo / MAX Mode
+ Version History
+ Special Thanks
+ Disclaimer

==================================================

Move List

U - Up           x - Light Punch       a - Light Kick
D - Down         y - Medium Punch      b - Medium Kick
F - Forward      z - Heavy Punch       c - Heavy Kick
B - Back         p - Any Punch         k - Any Kick
s - Start        2p - Two Punches      2k - Two Kicks

(EX): move has an EX version, performed by pressing 2 punch/kick buttons (costs 1/2 bar).
(MAX): use 2 punch/kick buttons when performing a Super Move to power it up (costs 2 bars).
(Lv.3): move costs 3 bars.

Normal:

Suncrack			B or F + 2p
Light Punish			B or F + 2k
Air Throw			B or F + 2k (during angled jump)
Sunbright			F + y
Easy Step			F + b
Little Lag			DF + b

Special:

Sunshot (EX)			D, DF, F, p
Sun Arch (EX)			F, D, DF, k
Sunrise (EX)			D, DF, F, k
Sun Upper (EX)			D, DB, B, p
Sun Lower (EX)			D, DB, B, k
Sundive (EX)			D, DB, B, k (Air)

Super:

Sunburst (MAX)			D, DF, F, D, DF, F, p
Sunshine (MAX)			D, DB, B, D, DB, B, k
Sun Drive (MAX)			D, DF, F, D, DF, F, k
Sun Delta (Lv.3)		D, DB, B, D, DB, B, 2p

==================================================

System

Forward Dash:			F, F
Run:				F, F (hold F)
Backward Dash:			B, B
Low Jump:			tap U
High Jump:			tap D, U
Long Low Jump:			tap D, tap U
Dodge:				a + x
Dodge Attack:			p or k during dodge
Forward Roll:			F + a + x
Backward Roll:			B + a + x
Parry:				tap F
Parry Low:			tap D
Air Parry:			tap F (Air)
Power Charge:			hold b + y
Zero Counter:			B, DB, D, p or k (during guard)
Custom Combo:			c + z (also in air)
MAX Mode:			c + z
Fall Recovery:			2p or a + x

==================================================

Move Details

• Sunbright is an Overhead.
• If canceled into, Sunbright will lose the Overhead property.
• EX Sunshot will disappear if Ingrid is hit (will not disappear if she is blocking.)
• Sun Arch and EX Sun Arch have a short invulnerability window at the start.
• EX Sunrise spin have invulnerability to projectiles, except for Super projectiles.
• Sun Upper can only counter standing moves. EX Sun Upper can counter both standing and air moves.
• Sun Upper and Sun Lower can only counter normals and specials. EX Sun Upper and EX Sun Lower can counter supers.
• Sunburst projectile will explode in a different range depending on the button strength.
• EX Sunburst projectile will explode when the opponent gets near, even if it doesn't make contact.
• Sun Delta is unblockable, and will appear in a different position depending on the button strength.

==================================================

Combo System

• Some Normal attacks can be canceled into Command Normal, Special and Super moves.
• Some Special moves can be canceled into Super moves.
• Some Lv1 Super moves can be canceled into MAX Super moves.
• Cancelling a Special, Super move or Custom Combo into a Super move resets the juggle points but also reduces its damage.

==================================================

Custom Combo

• Removes cancellable attack restrictions and gives you a lot of freedom to combo them.
• Juggle limite is lifted.
• You can only use EX Special or Super moves from the point the character starts flashing faster and brighter, and doing so ends Custom Combo.
• Gives you a short invulnerability window at the start.

MAX Mode

• Attack and Defense are increased while in MAX Mode.
• EX moves can be performed at no power cost, though take away from time sustained in MAX mode.
• All Lv1 Supers can be performed at no power cost, though immediately uses up all time in MAX mode.
• All Lv2 and higher Supers will cost 1 power bar, along with using up all time in MAX mode.
• Even without a power bar, as long as you have time left in MAX mode, you can perform Lv1 Supers/EX moves.
• You can not Power Charge/gain power while in MAX mode.
• You can not perform a Zero Counter/Counter Movement while in MAX Mode.

==================================================

Version History

14/January/2024

• Fixed FX's harsh shadows in mugen 1.0
• Fixed wrong Super name appearing in her lv3 super finish (Sun Drive instead of Sun Delta)
• Fixed afterimage not appearing during Custom Combo
• Added a new and much better small portrait

31/December/2023

• Now uses accurate boxes, velocities and damages from CFJ, with a few tweaks
• Added extended Color Separation (courtesy of DivineWolf) and new sprites (courtesy of sabockee and Xenomic)
• Fixed Sunshot not counting hits for the juggle system
• Added EX versions to Sun Upper, Sun Lower and Sundive
• Added Sun Drive
• Changed AI behavior
• Added special intro with DW's Kula Diamond and Karma's Blanka
• Many misc teaks and fixes
• Added many palettes

04/August/2019

• Fixed Sun Upper and Sun Lower FX and sound not disappearing if Ingrid is hit or blocking
• Normal Sunburst also explodes if opponent is near, jumping over or crouching

24/July/2019

• Added Explodsive Buffering System by Just No Point & Jmorphman
• Lots of fixing on juggles and priorities
• EX Moves consumes 1/3 of the bar in MAX Mode, like DW updated chars
• Refined code and removed unused codes
• Fixed sprpriority for projectiles appearing behind the players
• Changed AI behavior
• Fixed using Zero Counter during Max Mode, which should not be possible
• Added palettes
• Remade many animations for better timing
• Changed Sunrise velocity when the move makes contact, similar to SFA3 MAX
• Fixed problem with dampener when using normal and MAX Suburst

11/October/2018

• Misc tweaks and fixes
• Sun Upper can now counter air attacks
• Added turns intro
• Added palettes and a palette guide folder :P

02/October/2018

• Color Separation \o/
• Some small changes in the AI
• Sun Lower changed to statetype=C, and now goes back to crouch state instead of stand
• Fixed wrong position when recovering near ground
• Misc tweaks and fixes
• Re-did CLSN for hit animations
• Deleted unused effects sprites and animations
• Changed and added palettes

03/September/2018

• Misc tweaks and fixes

02/September/2018

• Misc tweaks and fixes

01/September/2018

• First Beta Released

Special Thanks

• DivineWolf, for providing the extended CS .sff, beta testing, suggestions and a lot of misc help
• Jesuszilla, for creating the CE tables
• KarmaCharmeleon, for teaching me how to use the tables and a lot of good general feedback
• Everyone from MugenGuild and MFFA, always helping and treating me super nice
• PotS, for the style and assets
• Jmorphman and DivineWolf, for reference I used to make my template
• Jmorphman (again) and Just No Point for the Explodsive Buffering System
• Rness/Rhythmical, for editing Ingrid and giving me motivation to update her, I used a lot of things from this edit
• InkTrebuchet, for the AI projectile detection code
• Memo, for the initial template
• sabockee and Xenomic, for the Midnight Bliss sprites
• Warusaki3, for some of Ingrid's sprites and sounds
• aokmaniac13, for some additional sprites (mostly effects)
• CrazyKoopa and MC2, for color-separated sprites
• -Whiplash-, for Ingrid's portraits from SFA3 MAX
• xcheatdeathx, for some sick hyper portraits
• Manson Rees, for coding help
• PeXXeR, ZolidSone, Trololo, .JSON, Raging Rowen and others, for testing and suggestions
• Devon, Rhythmical, Mysticus, Foobs, MT7 and others, for palettes
• Everyone at MFG, for feedback, and suggestions
• wiki.supercombo.gg, for the icons in the move list
• Elecbyte, for creating MUGEN
• VirtuallTek, for creating Fighter Factory
• Capcom, for creating Ingrid
• You, for downloading my char :D

==================================================

Disclaimer

Street Fighter, Capcom Fighting Jam and Capcom VS SNK 2 are property of Capcom.
This MUGEN character is a non-profit fan work, it cannot be used for any commercial purposes.
