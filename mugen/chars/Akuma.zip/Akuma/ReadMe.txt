 ______________________
| Akuma by DeathScythe |
 ����������������������
         04/August/2019

 - deathscythemugen.neocities.org -
 - victor_crepa@hotmail.com -

     ----------

Customized version of Akuma, for MUGEN 1.0.
Based on his Capcom VS SNK 2 appearance.
Customizable options, including alternate hitsparks and choosing between Custom Combo or
MAX Mode. Open "custom.txt" for info.
Two modes: Normal and Shin.
24 Palettes.
Many Hyper Portraits, Big Portraits and Win Portraits already inserted for you to choose.
Many Special Intros (with Patches):
	- Special Intro against Ryu by PotS (including edits by Mwryly, varo_hades & Beterhans)
	- Special Intro against Vega by PotS
	- Special Intro against Vega by Froz
	- Special Intro against Evil Ryu by Victorys
	- Special Intro against Gen by Mwryly & varo_hades
	- Special Intro against Haohmaru
Special Winpose using Shun Goku Satsu and Misogi.

     ----------

COMMENTS:

Oh, nice, one more Akuma... like we don't have thousand Akumas for MUGEN out there?
Yeah yeah, I know, but I could not resist making my favorite character of all fighting games.
Also, I felt that other Akumas either lack something or had too much, so I went to a more
"balanced" gameplay, close to his CvS2 moveset but retaining the PotS style that we all love.
I've put a lot of work and effort in this char to make it play different from the already
existing Akumas and not feel like an edit or something, I hope you enjoy. ^_^
This creation is opensource, you can take whatever you want from it, just give me credit
and give credit to people who I took resources from, see "SPECIAL THANKS" near the end of this
document to know more.

     ----------

MODES:

This character has two different modes:

Normal Akuma
- Does decent damage
- Can perform EX moves
- Has low defense

Shin Akuma
- Moves faster and has less recovery time
- Does more damage than Normal Akuma
- Can not perform EX moves
- Has the lowest defense

Note: If controlled by the AI, defense levels have no effect. This means that he has normal
defense (and does a little more damage than normal), much like in most games that he appear as
a boss.

Akuma.def:
Both chars in one file. Hold start to choose Shin Akuma (palettes 7 ~ 12)

NormalAkuma.def:
Only Normal Akuma

ShinAkuma.def:
Only Shin Akuma

     ----------

MOVELIST:

U - Up           x - Light Punch       a - Light Kick
D - Down         y - Medium Punch      b - Medium Kick
F - Forward      z - Heavy Punch       c - Heavy Kick
B - Back         p - Any Punch         k - Any Kick
s - Start        2p - Two Punches      2k - Two Kicks

(Air) - Move must be performed in the air
(EX)  - Move has an EX version, performed by pressing 2 punch/kick buttons
(MAX) - Use 2 punch/kick buttons when performing a Super Move to power it up

(N) - Only Normal Akuma
(S) - Only Shin Akuma


NORMAL:

Seoi Nage:			B or F + 2p
Tomoe Nage:			B or F + 2k
Zugai Hasatsu:			F + y
Tenma Kujin Kyaku:		D + b (Air)
Kikoku Tsuki (S):		(close) y, z

SPECIAL:

Gohadoken (EX):			D, DF, F, p
Shakunetsu Hadoken (EX):	F, DF, D, DB, B, p
Zanku Hadoken (EX):		D, DF, F, p (Air)
Goshoryuken (EX):		F, D, DF, p
Tatsumaki Zankukyaku (EX):	D, DB, B, k (Air also)
Hyakkishu (N) (EX):		F, D, DF, k
(After Hyakkishu):
	Hyakki Gouzan:			Do nothing
	Hyakki Goushou:			p
	Hyakki Goudan:			k
	Hyakki Gousai:			B or F + p (near opponent)
	Hyakki Goutsui:			B or F + k (near opponent)
Ashura Senku:			F, D, DF or B, D, DB, 3p or 3k (also 2p or 2k in Shin Mode)
Zenpou Tenshin (N):		D, DB, B, p
Tenma Shurettou (S):		D, D, 2p or 2k


SUPER:

Messatsu Gohado (MAX):		D, DB, B, D, DB, B, p
Messatsu Goshoryu (MAX):	D, DF, F, D, DF, F, p
Tenma Gozanku (MAX):		D, DF, F, D, DF, F, p (Air)

LV3 SUPER:

Shun Goku Satsu:		x, x, F, a, z
Kongou Kokuretsuzan (N):	D, D, D, 2p
Misogi (S):			F, DF, D, DB, B, 2k


SYSTEM:

Forward Dash:			F, F
Run:				F, F (hold F)
Backward Dash:			B, B
Low Jump:			tap U
High Jump:			tap D, U
Long Low Jump:			tap D, tap U
Dodge:				a + x
Dodge Attack:			p or k during dodge
Forward Roll:			F + a + x
Backward Roll:			B + a + x
Parry:				tap F
Parry Low:			tap D
Air Parry:			tap F (Air)
Power Charge:			hold b + y
Zero Counter:			B, DB, D, p or k (during guard)
Custom Combo:			c + z (also in air)
MAX Mode:			c + z
Fall Recovery:			2p or a + x

     ----------

MOVE DETAILS:

Zugai Hasatsu is an overhead
Gohadoken will make the opponent fall if used in a short distance
EX Hyakki Goudan and Kongou Kokuretsu Zan can hit lying down opponents
Ashura Senku and Zenpou Tenshin can be canceled into a Super without reducing damage
You can cancel some close normal attacks into Zugai Hasatsu

COMBO SYSTEM:

Some Normal attacks can be canceled into Special and Super moves
Some Special moves can be canceled into Super moves
Some Lv1 Super moves can be canceled into MAX Super moves
Cancelling a Special, Super move or Custom Combo into a Super move resets the juggle points
but also reduces its damage

CUSTOM COMBO:

Removes cancellable attack restrictions and gives you a lot of freedom to combo them
Juggle limite is lifted
You can only use EX Special or Super moves from the point the character starts flashing
faster and brighter, and doing so ends Custom Combo
Gives you a short invulnerability window at the start

MAX MODE:

Attack and Defense are increased while in MAX Mode
EX moves can be performed at no power cost, though take away from time sustained in MAX mode
All Lv1 supers can be performed at no power cost, though immediately uses up all time in MAX mode
All Lv2 and higher supers will cost 1 power bar, along with using up all time in MAX mode
Even without a power bar, as long as you have time left in MAX mode, you can perform Lv1 supers/EX moves
You can not Power Charge/gain power while in MAX mode
You can not perform a Zero Counter/Counter Movement while in MAX Mode

     ----------

VERSION HISTORY:

04/August/2019
Added envshake to Hyakkishu variants
Reduced damage for EX Zanku Hadoken and Shin Zanku Hadoken
Fixed Zanku Hadoken landing
Added reversal spark + guard sound for Tenma Shurettou
Added optional afterimage on EX moves
Fixed juggle problem on some projectiles that could cause an infinite

24/July/2019
Added Explodsive Buffering System by Just No Point & Jmorphman
Added Kikoku Tsuki
Added Kongou KokuretsuZan
Added intro vs Haohmaru
Added intro vs Beterhans' Ryu (he updated his Ryu with the intro, go to his site to get it :D)
Fixed Hyper Finish not triggering on the last hit of Messatsu Gohado and Tenma Gozanku
Fixed additional hit and damage on Tenma Gozanku
Fixed timing on throws
Changed target velocity when hit by EX Tatsumaki so now you almost always connect all 5 hits
Changed juggles and dampener for some moves to make it more balanced
Added AfterImage on second winpose (stomp)
Added Max Mode for AI
Changed AI behavior in Custom Combo
Fixed AI using Custom Combo even if you select to use Max Mode
Fixed AI using EX Moves during Custom Combo
EX Moves consumes 1/3 of the bar in Max Mode, like DW updated chars
Fixed using Zero Counter during Max Mode, which should not be possible
Fixed hitpauses
Fixed pushbacks and corner push
Changed velocities here and there
Added Palettes
Added Palette Guide
Fixed wrong changestate on Misogi
Fixed missaligned hitsparks on Tatsumaki Zankukyaku
Fixed both intros with Bison (Normal (SGS) and Shin (Misogi))
Fixed Kikoku Tsuki
Changed dampening for when canceling a special into Misogi

10/June/2019
Bug fixes
Added character specific winquotes \o/

09/June/2019
Centered Kanji (Shun Goku Satsu finishing)
Removed unused sprites (I always forget :rage:)
Fixed issue with Ashura Senku near edges
Some tweaks in the AI
Some tweaks on velocities and juggles for better combos
Fixed wrong statetype on MAX Tenma Gozanku
Projectiles now appear in front of the players when hit, not behind like before
Fixed some weird stuff happening on MUGEN 1.0
Added command with 2p or 2k for Ashura Senku in Shin Mode
Some minor aesthetic changes

08/June/2019
First Beta Released

     ----------

WHAT IS MISSING:

Maybe Messatsu Gorasen / Messatsu GoSenpu
Maybe CvS2 commands? Probably no one is going to use it...
Special Intro against Adon
Special Intro against Gouken

     ----------

KNOWN ISSUES:

None (that I'm aware)

     ----------

SECIAL THANKS:

Everyone from MugenGuild and MFFA always helping and treating me super nice
PotS, for custom sprites and style
Jmorphman and DivineWolf, for reference I used to make my template
Jmorphman (again) and Just No Point for the Explodsive Buffering System
Warusaki3 for reference on coding and some sounds that I borrowed
Froz for the Color Separation
Beterhans for adding the intro for Ryu
Sabockee for some sick pals
PeXXeR, SolidZone26 and Trololo, for testings and suggestions
gui007 for promoting my (and other creators) chars
Mysticus, Sabockee, and some others, for palettes
Everyone on MFG, for feedback and suggestions
VirtuallTek, for creating Fighter Factory
Elecbyte, for creating MUGEN
Capcom, for creating Akuma
You, for downloading my char :D

     ----------

DISCLAIMER:

Street Fighter, Capcom Fighting Evolution and Capcom VS SNK 2 are property of Capcom
This MUGEN character is a non-profit fan work, it cannot be used for any commercial purposes